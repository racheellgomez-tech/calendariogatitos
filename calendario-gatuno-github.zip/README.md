# Calendario gatuno 🐱

Web estática de calendario personal. La aplicación está contenida en `index.html` y no necesita dependencias, compilación, backend ni base de datos.

## Publicar en GitHub Pages

1. Crea un repositorio en GitHub.
2. Sube `index.html` a la **raíz** del repositorio (no dentro de una subcarpeta).
3. Abre **Settings → Pages**.
4. En **Build and deployment**, elige **Deploy from a branch**.
5. Selecciona la rama `main` y la carpeta `/(root)` y pulsa **Save**.
6. Espera a que termine el despliegue y abre la URL que aparecerá en esa misma página.

No uses `docs/` como carpeta de publicación salvo que muevas allí `index.html` y selecciones esa opción en Pages. El nombre debe ser exactamente `index.html` (minúsculas).

## Datos

Los eventos y ajustes se guardan en el almacenamiento local del navegador. No se sincronizan entre dispositivos ni entre usuarios. Usa la función de copia de seguridad de la aplicación para exportar/importar tus datos.
